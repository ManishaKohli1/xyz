# apmt-hybrid-cloud-automation
Automation code for Hybrid Cloud.

## tpc-harden: set hardening at OS
see documentation [here](tpc-harden/readme.md)


## kubespray: TPC installation - preinstall at os, crio, kubelet
```
1. setup cluster:
cd kubespray
ansible-playbook -i inventory/tpc1/hosts.yaml --user tpcadmin01 --become-method=sudo cluster-tpc.yml --skip-tags rhel-sub -vv |tee output.log

2. install hybridcloud-apps.yaml
cd kubespray
ansible-playbook -i inventory/tpc1/hosts.yaml --user tpcadmin01 --become-method=sudo hybridcloud-apps.yml -vv |tee output.log

3. reset cluster:
cd kubespray
ansible-playbook -i inventory/tpc1/hosts.yaml --user tpcadmin01 --become-method=sudo reset.yml

```
